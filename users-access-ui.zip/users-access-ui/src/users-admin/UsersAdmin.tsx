import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties, ReactNode } from 'react';
import * as db from './db';
import { authenticate } from './auth';
import type { LoginMethod, User, UsersState } from './types';
import {
  IconUsers, IconPlus, IconKey, IconCert, IconRefresh, IconLogout, IconLogin,
  IconClock, IconTrash, IconSearch, IconClose, IconUpload, IconEye, IconWorkspace,
} from './icons';
import './UsersAdmin.css';

const SESSION_HOURS = 8;
const CERT_ACCEPT = '.pfx,.p12,.cer,.crt,.pem';
const CHANNEL = 'users-admin';

/* ---------- helpers ---------- */
const newId = (): string => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()));
const sessionEnd = (u: User): number => u.lastLogin + SESSION_HOURS * 3600e3;
const isExpired = (u: User): boolean => Date.now() > sessionEnd(u);
const initials = (l: string): string => l.replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2).toUpperCase() || '?';
const methodName = (u: User): string => (u.method === 'cert' ? 'Сертификат' : 'Логин и пароль');
const fmt = (t: number): string =>
  new Date(t).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const HUES = [210, 265, 190, 330, 30, 250, 170, 290];
const hue = (id: string): number => { let h = 0; for (const c of id) h = (h * 31 + c.charCodeAt(0)) >>> 0; return HUES[h % HUES.length]; };
const errorText = (e: unknown, fallback: string): string => (e instanceof Error && e.message ? e.message : fallback);

/* ---------- data hook ---------- */
interface StoreState extends UsersState { ready: boolean; error: string | null }

interface UsersStore extends StoreState {
  addUser: (user: User) => Promise<void>;
  updateUser: (user: User) => Promise<void>;
  setActive: (id: string | null) => Promise<void>;
  removeUser: (id: string) => Promise<void>;
}

function useUsersStore(): UsersStore {
  const [state, setState] = useState<StoreState>({ users: [], activeId: null, ready: false, error: null });

  const reload = useCallback(async () => {
    try {
      const s = await db.loadState();
      setState({ ...s, ready: true, error: null });
    } catch (e) {
      setState((p) => ({ ...p, ready: true, error: errorText(e, 'Не удалось открыть хранилище') }));
    }
  }, []);

  useEffect(() => { void reload(); }, [reload]);

  // Синхронизация между вкладками
  useEffect(() => {
    if (!('BroadcastChannel' in window)) return;
    const ch = new BroadcastChannel(CHANNEL);
    ch.onmessage = () => { void reload(); };
    return () => ch.close();
  }, [reload]);

  const notify = () => {
    if (!('BroadcastChannel' in window)) return;
    const ch = new BroadcastChannel(CHANNEL);
    ch.postMessage('changed');
    ch.close();
  };

  const run = async (op: () => Promise<void>) => { await op(); await reload(); notify(); };

  return {
    ...state,
    addUser: (user) => run(() => db.saveUserAndActivate(user)),
    updateUser: (user) => run(() => db.saveUser(user)),
    setActive: (id) => run(() => db.setActiveId(id)),
    removeUser: (id) => run(() => db.deleteUser(id)),
  };
}

/* ---------- small building blocks ---------- */
interface PasswordInputProps {
  id: string;
  value: string;
  onChange: (value: string) => void;
  onEnter?: () => void;
  autoFocus?: boolean;
}

function PasswordInput({ id, value, onChange, onEnter, autoFocus }: PasswordInputProps) {
  const [show, setShow] = useState(false);
  const label = show ? 'Скрыть пароль' : 'Показать пароль';
  return (
    <div className="ua-pw">
      <input className="ua-inp" id={id} type={show ? 'text' : 'password'} autoComplete="current-password"
        value={value} onChange={(e) => onChange(e.target.value)} autoFocus={autoFocus}
        onKeyDown={(e) => { if (e.key === 'Enter') onEnter?.(); }} />
      <button type="button" className="ua-eye" aria-pressed={show} aria-label={label} title={label}
        onClick={() => setShow((s) => !s)}><IconEye off={show} /></button>
    </div>
  );
}

interface FilePickerProps {
  fileName: string | null;
  placeholder: string;
  onFile: (file: File) => void;
}

function FilePicker({ fileName, placeholder, onFile }: FilePickerProps) {
  const [over, setOver] = useState(false);
  const stop = (e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); };
  return (
    <label className={`ua-file${fileName ? ' set' : ''}${over ? ' over' : ''}`}
      onDragEnter={(e) => { stop(e); setOver(true); }} onDragOver={stop}
      onDragLeave={(e) => { stop(e); setOver(false); }}
      onDrop={(e) => { stop(e); setOver(false); const f = e.dataTransfer.files[0]; if (f) onFile(f); }}>
      <IconUpload />
      <span>{fileName ?? placeholder}</span>
      <input type="file" accept={CERT_ACCEPT} onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }} />
    </label>
  );
}

interface ModalProps { open: boolean; onClose: () => void; labelledBy: string; children: ReactNode }

function Modal({ open, onClose, labelledBy, children }: ModalProps) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog ref={ref} className="ua-dialog" aria-labelledby={labelledBy}
      onCancel={(e) => { e.preventDefault(); onClose(); }}>
      {open && children}
    </dialog>
  );
}

/* ---------- active card ---------- */
interface ActiveCardProps { user: User | null; hasUsers: boolean; onRefresh: () => void; onLogout: () => void }

function ActiveCard({ user, hasUsers, onRefresh, onLogout }: ActiveCardProps) {
  if (!user) {
    return (
      <div className="ua-active none">
        {hasUsers ? 'Активный пользователь не выбран. Нажмите «Войти» у нужного пользователя.' : 'Пользователей пока нет. Нажмите «Добавить пользователя».'}
      </div>
    );
  }
  const ex = isExpired(user);
  return (
    <div className={`ua-active${ex ? ' exp' : ''}`}>
      <div className="ua-bigav">{initials(user.login)}</div>
      <div className="ua-info">
        <div>
          <div className="ua-nm">{user.login}</div>
          <div className="ua-mt">{methodName(user)}{user.cert ? `, ${user.cert.name}` : ''}</div>
        </div>
        <div className="ua-times">
          <div><IconLogin /><span><small>Начало сессии</small><b>{fmt(user.lastLogin)}</b></span></div>
          <div><IconClock /><span><small>{ex ? 'Истекла' : 'Истекает'}</small><b className={ex ? 'bad' : ''}>{fmt(sessionEnd(user))}</b></span></div>
        </div>
      </div>
      <div className="ua-side">
        <div className="ua-ops">
          <button type="button" className={`ua-btn${ex ? ' primary' : ''}`} onClick={onRefresh}><IconRefresh />Обновить сессию</button>
          <button type="button" className="ua-btn danger" onClick={onLogout}><IconLogout />Выйти</button>
        </div>
      </div>
    </div>
  );
}

/* ---------- users table ---------- */
interface UsersTableProps {
  users: User[];
  allUsers: User[];
  activeId: string | null;
  onActivate: (user: User) => void;
  onDelete: (user: User) => void;
}

function UsersTable({ users, allUsers, activeId, onActivate, onDelete }: UsersTableProps) {
  const hasDupes = (u: User) => allUsers.filter((x) => x.login.toLowerCase() === u.login.toLowerCase()).length > 1;
  if (!users.length) {
    return <div className="ua-tw"><div className="ua-empty">{allUsers.length ? 'Ничего не найдено' : 'Список пуст'}</div></div>;
  }
  return (
    <div className="ua-tw">
      <table className="ua-table">
        <thead>
          <tr><th>Пользователь</th><th>Способ входа</th><th>Статус</th><th>Последний вход</th><th><span className="ua-sr">Действия</span></th></tr>
        </thead>
        <tbody>
          {users.map((u) => {
            const on = u.id === activeId;
            const ex = isExpired(u);
            return (
              <tr key={u.id} className={on ? 'on' : ''}>
                <td>
                  <div className="ua-user">
                    <span className="ua-av" style={{ '--h': hue(u.id) } as CSSProperties}>{initials(u.login)}</span>
                    <span>{u.login}{hasDupes(u) && u.cert && <small>{u.cert.name}</small>}</span>
                  </div>
                </td>
                <td>
                  <span className={`ua-meth${u.method === 'cert' ? ' cert' : ''}`}>
                    {u.method === 'cert' ? <IconCert /> : <IconKey />}{methodName(u)}
                  </span>
                </td>
                <td>
                  {on && !ex ? <span className="ua-st on"><i />Активен</span>
                    : ex ? <span className="ua-st exp"><i />Сессия истекла</span>
                    : <span className="ua-st"><i />Доступен</span>}
                </td>
                <td className="ua-when">{fmt(u.lastLogin)}</td>
                <td>
                  <div className="ua-acts">
                    {on ? <span className="ua-ib ph" aria-hidden="true" />
                      : <button type="button" className="ua-ib go" title="Войти" aria-label={`Войти: ${u.login}`} onClick={() => onActivate(u)}><IconLogin /></button>}
                    {on ? <span className="ua-ib ph" aria-hidden="true" />
                      : <button type="button" className="ua-ib del" title="Удалить" aria-label={`Удалить ${u.login}`} onClick={() => onDelete(u)}><IconTrash /></button>}
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/* ---------- add drawer ---------- */
interface AddDrawerProps { open: boolean; users: User[]; onClose: () => void; onCreate: (user: User) => Promise<void> }

const METHODS: { value: LoginMethod; icon: ReactNode; title: string; sub: string }[] = [
  { value: 'password', icon: <IconKey />, title: 'Логин и пароль', sub: 'Обычная авторизация' },
  { value: 'cert', icon: <IconCert />, title: 'Сертификат', sub: 'Вход по сертификату' },
];

function AddDrawer({ open, users, onClose, onCreate }: AddDrawerProps) {
  const [method, setMethod] = useState<LoginMethod>('password');
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const close = useCallback(() => { setError(''); onClose(); }, [onClose]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape' && !document.querySelector('dialog[open]')) close(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, close]);

  const pickFile = (f: File) => {
    setFile(f);
    if (!login.trim()) setLogin(f.name.replace(/\.(pfx|p12|cer|crt|pem)$/i, ''));
  };

  const submit = async () => {
    const l = login.trim();
    setError('');
    if (method === 'cert' && !file) return setError('Выберите файл сертификата');
    if (!l) return setError('Введите логин');
    if (!password) return setError('Введите пароль');
    const certName = file?.name ?? null;
    const exists = users.some((u) =>
      u.login.toLowerCase() === l.toLowerCase() && u.method === method && (method === 'password' || u.cert?.name === certName));
    if (exists) return setError('Такой пользователь уже добавлен');

    setBusy(true);
    try {
      await authenticate({ login: l, password, certificate: file });
      const now = Date.now();
      await onCreate({
        id: newId(), login: l, method,
        cert: method === 'cert' && file ? { name: file.name, blob: file } : null,
        createdAt: now, lastLogin: now,
      });
      setLogin(''); setPassword(''); setFile(null);
      onClose();
    } catch (e) {
      setError(errorText(e, 'Не удалось войти'));
    } finally {
      setBusy(false);
    }
  };

  if (!open) return null;
  const isCert = method === 'cert';
  return (
    <>
      <div className="ua-scrim" onClick={close} />
      <aside className="ua-drawer" aria-labelledby="ua-add-title">
        <div className="ua-dh">
          <h2 id="ua-add-title">Новый пользователь</h2>
          <button type="button" className="ua-x" aria-label="Закрыть" onClick={close}><IconClose /></button>
        </div>
        <p className="ua-desc">Новый пользователь сразу станет активным.</p>
        <div className="ua-db">
          <div className="ua-fg">
            <span className="ua-lbl" id="ua-method-lbl">Способ входа</span>
            <div className="ua-tiles" role="radiogroup" aria-labelledby="ua-method-lbl">
              {METHODS.map((m) => (
                <label key={m.value} className="ua-tile">
                  <input type="radio" name="ua-method" value={m.value} checked={method === m.value}
                    onChange={() => { setMethod(m.value); setError(''); }} />
                  {m.icon}<b>{m.title}</b><small>{m.sub}</small>
                </label>
              ))}
            </div>
          </div>
          {isCert && (
            <div className="ua-fg">
              <span className="ua-lbl">Файл сертификата</span>
              <FilePicker fileName={file?.name ?? null} placeholder="Выберите .pfx, .p12, .cer, .crt или .pem" onFile={pickFile} />
            </div>
          )}
          <div className="ua-fg">
            <label className="ua-lbl" htmlFor="ua-login">Логин</label>
            <input className="ua-inp" id="ua-login" autoComplete="username" spellCheck={false} autoFocus
              value={login} onChange={(e) => setLogin(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') void submit(); }} />
          </div>
          <div className="ua-fg">
            <label className="ua-lbl" htmlFor="ua-password">{isCert ? 'Пароль сертификата' : 'Пароль'}</label>
            <PasswordInput id="ua-password" value={password} onChange={setPassword} onEnter={() => void submit()} />
          </div>
          <div className="ua-err" role="alert">{error}</div>
        </div>
        <div className="ua-df">
          <button type="button" className="ua-btn" onClick={close}>Отмена</button>
          <button type="button" className="ua-btn primary" disabled={busy} onClick={() => void submit()}>
            {busy ? 'Создание…' : 'Создать пользователя'}
          </button>
        </div>
      </aside>
    </>
  );
}

/* ---------- re-login dialog ---------- */
interface ReloginTarget { user: User; activate: boolean }
interface ReloginDialogProps {
  target: ReloginTarget | null;
  onClose: () => void;
  onDone: (updated: User, activate: boolean) => Promise<void>;
}

function ReloginDialog({ target, onClose, onDone }: ReloginDialogProps) {
  const [password, setPassword] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const user = target?.user ?? null;

  useEffect(() => { setPassword(''); setFile(null); setError(''); }, [user?.id]);

  const submit = async () => {
    if (!target) return;
    if (!password) return setError('Введите пароль');
    setBusy(true); setError('');
    try {
      const { user: u, activate } = target;
      await authenticate({ login: u.login, password, certificate: file ?? u.cert?.blob ?? null });
      await onDone({ ...u, lastLogin: Date.now(), cert: file ? { name: file.name, blob: file } : u.cert }, activate);
      onClose();
    } catch (e) {
      setError(errorText(e, 'Не удалось войти'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={!!target} onClose={onClose} labelledBy="ua-re-title">
      {user && target && (
        <>
          <h2 id="ua-re-title">{target.activate ? 'Вход: ' : 'Обновить сессию: '}{user.login}</h2>
          {user.method === 'cert' && (
            <div className="ua-fg">
              <span className="ua-lbl">Сертификат</span>
              <FilePicker fileName={file?.name ?? user.cert?.name ?? null} placeholder="Выберите файл" onFile={setFile} />
            </div>
          )}
          <label className="ua-lbl" htmlFor="ua-re-pw">{user.method === 'cert' ? 'Пароль сертификата' : 'Пароль'}</label>
          <PasswordInput id="ua-re-pw" value={password} onChange={setPassword} onEnter={() => void submit()} autoFocus />
          <div className="ua-err" role="alert" style={{ marginTop: 8 }}>{error}</div>
          <div className="ua-dfoot">
            <button type="button" className="ua-btn" onClick={onClose}>Отмена</button>
            <button type="button" className="ua-btn primary" disabled={busy} onClick={() => void submit()}>{busy ? 'Вход…' : 'Войти'}</button>
          </div>
        </>
      )}
    </Modal>
  );
}

/* ---------- main ---------- */
export interface UsersAdminProps {
  /** Адрес интерфейса приложения. Если не задан вместе с onBack, кнопка перехода не показывается. */
  backHref?: string;
  /** Переход в приложение (например, navigate из роутера). Если задан, используется вместо backHref. */
  onBack?: () => void;
}

export default function UsersAdmin({ backHref, onBack }: UsersAdminProps = {}) {
  const store = useUsersStore();
  const { users, activeId, ready, error } = store;
  const [drawer, setDrawer] = useState(false);
  const [query, setQuery] = useState('');
  const [re, setRe] = useState<ReloginTarget | null>(null);
  const [toDelete, setToDelete] = useState<User | null>(null);
  const [toast, setToast] = useState('');
  const toastTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const say = (m: string) => {
    setToast(m);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 2200);
  };

  // Если пользователей нет — сразу открыть форму
  useEffect(() => { if (ready && !users.length) setDrawer(true); }, [ready, users.length]);

  // Раз в минуту перерисовать, чтобы статус «Сессия истекла» появлялся сам
  const [, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 60e3);
    return () => clearInterval(t);
  }, []);

  const active = users.find((u) => u.id === activeId) ?? null;
  // Вернуться в приложение можно, только если есть куда и выбран активный пользователь с действующей сессией
  const canGoBack = !!(onBack || backHref) && !!active && !isExpired(active);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return users;
    return users.filter((u) => u.login.toLowerCase().includes(q) || (u.cert?.name ?? '').toLowerCase().includes(q));
  }, [users, query]);

  const handleActivate = async (u: User) => {
    if (isExpired(u)) return setRe({ user: u, activate: true });
    await store.setActive(u.id);
    say(`Активный: ${u.login}`);
  };

  const handleReloginDone = async (updated: User, activate: boolean) => {
    await store.updateUser(updated);
    if (activate) await store.setActive(updated.id);
    say(activate ? `Активный: ${updated.login}` : 'Сессия обновлена');
  };

  const confirmDelete = async () => {
    if (!toDelete) return;
    const u = toDelete;
    setToDelete(null);
    await store.removeUser(u.id);
    say(`Пользователь ${u.login} удалён`);
  };

  return (
    <div className="ua">
      <main className="ua-main">
        <div className="ua-head">
{canGoBack && (onBack ? (
            <button type="button" className="ua-back" onClick={onBack} aria-label="Вернуться в приложение" title="Вернуться в приложение"><IconWorkspace /></button>
          ) : (
            <a className="ua-back" href={backHref} aria-label="Вернуться в приложение" title="Вернуться в приложение"><IconWorkspace /></a>
          ))}
          <div className="ua-hi"><IconUsers /></div>
          <div className="ua-grow"><h1>Пользователи</h1><p>Управление локальными пользователями и переключение сессий</p></div>
          <button type="button" className="ua-btn primary" onClick={() => setDrawer(true)}><IconPlus />Добавить пользователя</button>
        </div>

        {error && <div className="ua-alert" role="alert">Хранилище недоступно: {error}</div>}

        <section className="ua-section" aria-labelledby="ua-act-title">
          <h2 id="ua-act-title">Активный пользователь</h2>
          {ready && (
            <ActiveCard user={active} hasUsers={users.length > 0}
              onRefresh={() => { if (active) setRe({ user: active, activate: false }); }}
              onLogout={() => { void store.setActive(null).then(() => say('Сессия завершена')); }} />
          )}
        </section>

        <label className="ua-search">
          <span className="ua-sr">Поиск</span>
          <IconSearch />
          <input type="search" placeholder="Поиск пользователей…" autoComplete="off" value={query} onChange={(e) => setQuery(e.target.value)} />
        </label>

        <h2 className="ua-lt">Доступные пользователи</h2>
        {ready && (
          <UsersTable users={filtered} allUsers={users} activeId={activeId}
            onActivate={(u) => { void handleActivate(u); }} onDelete={setToDelete} />
        )}
      </main>

      <AddDrawer open={drawer} users={users} onClose={() => setDrawer(false)}
        onCreate={async (u) => { await store.addUser(u); say(`Пользователь ${u.login} создан и активен`); }} />

      <ReloginDialog target={re} onClose={() => setRe(null)} onDone={handleReloginDone} />

      <Modal open={!!toDelete} onClose={() => setToDelete(null)} labelledBy="ua-del-title">
        {toDelete && (
          <>
            <h2 id="ua-del-title">Удалить пользователя</h2>
            <p>Удалить «{toDelete.login}» из списка?</p>
            <div className="ua-dfoot">
              <button type="button" className="ua-btn" onClick={() => setToDelete(null)}>Отмена</button>
              <button type="button" className="ua-btn danger-fill" onClick={() => void confirmDelete()}>Удалить</button>
            </div>
          </>
        )}
      </Modal>

      <div className={`ua-toast${toast ? ' show' : ''}`} role="status">{toast}</div>
    </div>
  );
}
