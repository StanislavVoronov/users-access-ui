// Хранилище пользователей в IndexedDB (без сторонних библиотек).
// База: "users-admin", хранилища: "users" (ключ id) и "meta" (activeId).
import type { User, UserRecord, UsersState } from './types';

const DB_NAME = 'users-admin';
const DB_VERSION = 1;
const USERS = 'users';
const META = 'meta';
const ACTIVE_KEY = 'activeId';

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(USERS)) {
        const users = db.createObjectStore(USERS, { keyPath: 'id' });
        users.createIndex('login', 'loginLower', { unique: false });
      }
      if (!db.objectStoreNames.contains(META)) db.createObjectStore(META);
    };
    req.onsuccess = () => {
      const db = req.result;
      // Если другая вкладка обновит схему — закрываемся, чтобы не блокировать её
      db.onversionchange = () => { db.close(); dbPromise = null; };
      resolve(db);
    };
    req.onerror = () => { dbPromise = null; reject(req.error); };
    req.onblocked = () => reject(new Error('База данных занята другой вкладкой'));
  });
  return dbPromise;
}

/** Выполнить действие в транзакции и дождаться её завершения. */
async function tx<T>(stores: string[], mode: IDBTransactionMode, fn: (t: IDBTransaction) => T | Promise<T>): Promise<T> {
  const db = await openDb();
  return new Promise<T>((resolve, reject) => {
    const t = db.transaction(stores, mode);
    let result: T;
    Promise.resolve(fn(t)).then((r) => { result = r; }, reject);
    t.oncomplete = () => resolve(result);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error ?? new Error('Транзакция отменена'));
  });
}

function wrap<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

const toRecord = (u: User): UserRecord => ({ ...u, loginLower: u.login.toLowerCase() });
const fromRecord = ({ loginLower: _omit, ...u }: UserRecord): User => u;

export function loadState(): Promise<UsersState> {
  return tx([USERS, META], 'readonly', async (t) => {
    const [records, activeId] = await Promise.all([
      wrap(t.objectStore(USERS).getAll() as IDBRequest<UserRecord[]>),
      wrap(t.objectStore(META).get(ACTIVE_KEY) as IDBRequest<string | undefined>),
    ]);
    const users = records.map(fromRecord).sort((a, b) => a.createdAt - b.createdAt);
    return { users, activeId: activeId ?? null };
  });
}

export function saveUser(user: User): Promise<void> {
  return tx([USERS], 'readwrite', (t) => { t.objectStore(USERS).put(toRecord(user)); });
}

/** Сохранить пользователя и сделать его активным — одной транзакцией. */
export function saveUserAndActivate(user: User): Promise<void> {
  return tx([USERS, META], 'readwrite', (t) => {
    t.objectStore(USERS).put(toRecord(user));
    t.objectStore(META).put(user.id, ACTIVE_KEY);
  });
}

export function setActiveId(id: string | null): Promise<void> {
  return tx([META], 'readwrite', (t) => {
    if (id == null) t.objectStore(META).delete(ACTIVE_KEY);
    else t.objectStore(META).put(id, ACTIVE_KEY);
  });
}

/** Удалить пользователя; если он был активным — снять активного. */
export function deleteUser(id: string): Promise<void> {
  return tx([USERS, META], 'readwrite', async (t) => {
    t.objectStore(USERS).delete(id);
    const active = await wrap(t.objectStore(META).get(ACTIVE_KEY) as IDBRequest<string | undefined>);
    if (active === id) t.objectStore(META).delete(ACTIVE_KEY);
  });
}
