import type { ReactNode } from 'react';

const S = ({ children, w = 2 }: { children: ReactNode; w?: number }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{children}</svg>
);

export const IconUsers = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <circle cx="9" cy="8" r="4" /><path d="M1.5 20c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5z" />
    <circle cx="17" cy="9" r="3" opacity=".6" /><path d="M17.5 13.6c3 .3 5 2.4 5 5.4h-4.3c0-2-.3-3.7-.7-5.4z" opacity=".6" />
  </svg>
);
export const IconPlus = () => <S w={2.2}><path d="M12 5v14M5 12h14" /></S>;
export const IconKey = () => <S w={1.8}><circle cx="8" cy="15" r="4" /><path d="M11 12l9-9" /><path d="M17 6l3 3" /><path d="M15 8l2 2" /></S>;
export const IconCert = () => <S w={1.8}><path d="M14 3H6v18h12V7z" /><path d="M14 3v4h4" /><path d="M9 12h6M9 16h6" /></S>;
export const IconRefresh = () => <S><path d="M21 12a9 9 0 1 1-2.64-6.36" /><path d="M21 3v6h-6" /></S>;
export const IconLogout = () => <S><path d="M10 4H5v16h5" /><path d="M15 8l4 4-4 4" /><path d="M19 12H9" /></S>;
export const IconLogin = () => <S w={1.8}><path d="M10 17l5-5-5-5" /><path d="M15 12H3" /><path d="M15 4h4v16h-4" /></S>;
export const IconClock = () => <S w={1.8}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></S>;
export const IconTrash = () => <S><path d="M4 7h16" /><path d="M9 7V4h6v3" /><path d="M6 7l1 13h10l1-13" /></S>;
export const IconSearch = () => <S><circle cx="11" cy="11" r="7" /><path d="M20 20l-4-4" /></S>;
export const IconClose = () => <S><path d="M6 6l12 12M18 6L6 18" /></S>;
export const IconUpload = () => <S><path d="M12 16V4" /><path d="M7 9l5-5 5 5" /><path d="M4 20h16" /></S>;
export const IconEye = ({ off = false }: { off?: boolean }) => (
  <S><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" />{off && <path d="M3 3l18 18" />}</S>
);
export const IconWorkspace = () => <S><rect x="4" y="4" width="16" height="16" rx="2" /><path d="M4 9h8" /><path d="M12 15h8" /><path d="M12 4v16" /></S>;
