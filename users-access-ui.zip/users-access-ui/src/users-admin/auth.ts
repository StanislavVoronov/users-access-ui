import type { AuthParams } from './types';

// Заглушка входа. Замените на вызов вашего API.
// resolve — вход выполнен, reject(Error) — ошибка с текстом для пользователя.
export function authenticate({ password }: AuthParams): Promise<void> {
  return new Promise((resolve, reject) =>
    setTimeout(() => (password.length < 4 ? reject(new Error('Неверный пароль')) : resolve()), 500),
  );
}
