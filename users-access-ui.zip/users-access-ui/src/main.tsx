import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import UsersAdmin from './users-admin/UsersAdmin';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <UsersAdmin />
  </StrictMode>,
);
