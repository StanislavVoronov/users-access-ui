export type LoginMethod = 'password' | 'cert';

export interface StoredCert {
  name: string;
  /** Файл сертификата (File наследует Blob). В IndexedDB сохраняется как Blob. */
  blob: Blob;
}

export interface User {
  id: string;
  login: string;
  method: LoginMethod;
  cert: StoredCert | null;
  createdAt: number;
  lastLogin: number;
}

/** Запись в IndexedDB: пользователь плюс поле для индекса по логину. */
export interface UserRecord extends User {
  loginLower: string;
}

export interface UsersState {
  users: User[];
  activeId: string | null;
}

export interface AuthParams {
  login: string;
  password: string;
  certificate: Blob | null;
}
